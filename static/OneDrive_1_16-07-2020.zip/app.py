# imports
from __future__ import print_function
from flask import Flask, render_template, request,url_for
import re
import random

class Chat(object):
    def __init__(self, pairs,reflections={}):
        self._pairs = [(re.compile(x, re.IGNORECASE), y) for (x, y) in pairs]
        self._reflections = reflections
        self._regex = self._compile_reflections()

    def _compile_reflections(self):
        sorted_refl = sorted(self._reflections.keys(), key=len, reverse=True)
        return re.compile(r"\b({0})\b".format("|".join(map(re.escape, sorted_refl))), re.IGNORECASE)
    def _substitute(self, str):
        return self._regex.sub( lambda mo: self._reflections[mo.string[mo.start() : mo.end()]],str.capitalize())
    
    def _wildcards(self, response, match):
        pos = response.find('%')
        while pos >= 0:
            num = int(response[pos + 1 : pos + 2])
            response = (
                response[:pos]
                + self._substitute(match.group(num))
                + response[pos + 2 :]
            )
            pos = response.find('%')
        return response
        
    def respond(self, str):
        for (pattern, response) in self._pairs:
            match = pattern.match(str)

            if match:
                resp = random.choice(response) 
                resp = self._wildcards(resp, match)  

                if resp[-2:] == '?.':
                    resp = resp[:-2] + '.'
                if resp[-2:] == '??':
                    resp = resp[:-2] + '?'
                return resp
reflections = {
          "i am"       : "you are",
            "i was"      : "you were",
              "i"          : "you",
                "i'm"        : "you are",
                  "i'd"        : "you would",
                    "i've"       : "you have",
                      "i'll"       : "you will",
                        "my"         : "your",
                          "you are"    : "I am",
                            "you were"   : "I was",
                              "you've"     : "I have",
                                "you'll"     : "I will",
                                  "your"       : "my",
                                    "yours"      : "mine",
                                      "you"        : "me",
                                        "me"         : "you"
                                        }
pairs = [
    [
        r"my name is (.*)",
        ["Hello %1, Please enter your Appointment Number",]
    ],
     [
        r"this is (.*)",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Hi %1, I will help in finding suitable hospitals for you</br>Choose a specialty in which you are looking for a doctor:</h3><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Allergy</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>ENT</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Cardiology</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Radiation Oncology</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Dental Sciences</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Gastroenterology</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Paediatrics</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Gynaecology</button></p></div>",]
    ],
    [
        r"Myself (.*)",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Hi %1, I will be helping you today in connecting you to appropriate doctor</h3><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Hospitals in India</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Internationals Hospitals</button></p></div>"]
    ],
     [
        r"I am (.*)",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Hello %1, I will be helping you today with your appointment</br>Book appointment for:</h3><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Self</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Someone Else</button></p></div>"]
    ],
    [
        r"Book Appointment|book|BOOK",    
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please Enter your name</br>Format: enter your name like the mention format:</br>I am _______</h3></div>"]
    ],
     [
        r"hi|hey|hello|namaste",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Thanks for getting in touch with us at Apollo Hospitals today and I am here to help you</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Book Appointment</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Check Appointment Status</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Locate Hospital</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Find a doctor</button></p></div>"]
    ],
    
    [
        r"Check Appointment status|check|CHECK|Check|check appointment status|Check Appointment|check appointment|Appointment|appointment|APPOINTMENT",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please Enter your name</br>Format: enter your name like the mention format:</br>My name is ______</h3></div>",]
    ],
    [
        r"Self|self|SELF",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Can you please select the specialty for which you are looking a doctor</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Allergy</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>ENT</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Cardiology</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Radiation Oncology</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Dental Sciences</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Gastroenterology</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Paediatrics</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Gynaecology</button></p></div>"]
    ],
    
    [
        r"Allergy|allergy|ALLERGY",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please enter your preferred location for the appointment</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>I will enter my location</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Fetch my location</button></p></div>",]
    ],
    [
        r"Locate",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please Enter your name</br>Format: enter your name like the mention format:</br>Myself______</h3></div>"]
        
    ],
    [
        r"Hospitals in india",
        ["<p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Delhi</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Kolkata</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Mumbai</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Lucknow</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Banglore</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Chennai</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Search</button></p>"]
        
    ],  
    [
        r"International Hospitals",
        ["<p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Dhaka</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Muscat</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Search</button></p>"]
    ],
    
    [
        r"find",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please Enter your name</br>Format: enter your name like the mention format:</br>This is ______</h3></div>"]
    ],
    
    [
        r"Basic Plan|BASIC|basic|Basic",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>You have chosen Basic Plan</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Please Confirm</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Yes</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>No</button></p></div>",]
        
    ],
    [
        r"Connect to an Executive|Executive|EXECUTIVE|executive|support|Support|SUPPORT|connect|Connect|CONNECT",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Our Executive will call you shortly</h3></div>",]
    ],
    [
        r"Discounted Add-Ons?|Discount|discount|DISCOUNT",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Buy HDFC basic plan and get NIC short term insurance free</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Buy NIC basic plan and get LIC</br>short term insurance free</button></p></div>",]
    ],
    [
        r"Frequently Bought Together|Bought|BOUGHT|bought|together|Together|TOGETHER|Frequently|FREQUENTLY|frequently",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>HDFC Basic Plan + LIC children care policy</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>LIC Premium Plan + NIC short term insurance</button></p></div>"]
    ],
    [
        r"Date: (.*)",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Your appointment with Dr Nandan for %1 is confirmed</h3></div>",]
    ],
    [
        r"thankyou|Thankyou|Thanks|fine|okay|Okay|good|GoodThank you|thank you|thanks|thanku|Thanku",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>It's pleasure talking to you :)</h3></div>"]
    ],
    [
        r'^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$',
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Kindly check your mail, we have sent your Policy papers</h3></div>",]
    ],
    [
        r"Premium Plan|Premium|premium",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>You have chosen Premium Plan</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Please Confirm</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Yes</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>No</button></p></div>"]
    ],
    [
        r"Yes|yes|YES",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Write \"Done\" after clicking below link\nwww.paymentkaro.com</h3></div>"]
    ],
    [
        r"No|NO|no",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>You denied a process.\nSay Hi to start again</h3></div>"]
    ],
    
    [
        r"Dr Nandan Paediatrics",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please enter your preferred date and time</br>Use Format:</br>Date: DD/MM/YYYY at HH:MM AM/PM</h3></div>"]
    ],
    [
        r"Dr Nandan",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please enter your location to find hospitals near you</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Gurugram</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Noida</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Pitampura</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Dehradun</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Chandigarh</button></p></div>"]
    ],
    [
        r"Dr Shashi",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please enter your location to find hospitals near you</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Gurugram</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Noida</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Pitampura</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Dehradun</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Chandigarh</button></p></div>"]
    ],
    [
        r"I will enter my location",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please enter your location to find hospitals near you</br>Use Format: H.no [your address] </br> Eg. H.no 682329/137 urban etsate karshetra</h3></div>"]
    ],
    [
        r"H.no (.*)",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Please select the doctor you would like to consult</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;'>Dr Nandan Paediatrics</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;'>Dr ShashiCardiology</button></p></div>"
]
    ],
      [
        r"Contact the Doctor|contact|Contact|CONTACT",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Your appointment with Dr Rahul for 20/12/2019 at time is confirmed</h3></div>"]
],
    [
        r"quit|bye|Bye|BYE|end|END|End|QUIT|Quit",
        ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>BBye take care. See you soon :) ","It was nice talking to you. See you soon :)</h3></div>"]
],
    
     [
         r"^[0-9A-F]+$",
         ["<div class='uk-card uk-card-default uk-card-body uk-width-3@m'><h3 class='uk-card-title'>Your appointment is confirmed for today at 4pm with doctor Rahul. We hope to see you at our hospital today.</h3></br><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Can I be of any more assistance?</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Contact the Doctor</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Reschedule the Appointment</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Cancel the Appointment</button></p><p class='uk-margin'><button class='uk-button uk-button-primary' style='font-size: 0.75rem;padding: -1px 30px;'>Contact hospital</button></p></div>"]

     ],
]
def chatty():
    chat = Chat(pairs,reflections)
    x = chat.respond('Nic')
    print(x)
    
app = Flask(__name__)

#define app routes
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get")
#function for the bot response
def get_bot_response():
    userText = request.args.get('msg')
    chat = Chat(pairs,reflections)
    #print(chat.respond(userText))
    return (chat.respond(userText))
    
if __name__ == "__main__":
    app.run(host='0.0.0.0',port=8090)
